const songModel = require("../models/song.model")
const asyncHandler = require('express-async-handler')
const id3 = require('node-id3')
const storageService = require('../services/storage.service')

const uploadSong = asyncHandler(async (req,res)=>{
    const songBuffer = req.file.buffer
    const {mood} = req.body
    const tag = id3.read(songBuffer)
    
    const songFile = await storageService.uploadFile({
        buffer:songBuffer,
        fileName:tag.title+".mp3",
        folder:"/cohort-2/AuraPlay/songs"
    })

    const posterFile = await storageService.uploadFile({
        buffer:tag.image.imageBuffer,
        fileName:tag.title+".jpeg",
        folder:"/cohort-2/AuraPlay/posters"
    })

    const song = await songModel.create({
        url:songFile.Url,
        posterUrl:posterFile.Url,
        title:tags.title,
        mood
    })

    res.status(201).json({
        message:"song created successfully",
        song
    })


    
})


module.exports = {
    uploadSong
}